import cv2
import pytesseract

pytesseract.pytesseract.tesseract_cmd = r"C:\tesseract\tesseract.exe" # путь к исполняемому файлу tesseract
lang_model = 'rus'

# создание объекта VideoCapture для захвата кадров с камеры
cap = cv2.VideoCapture(0)

while True:
    # захват кадра с камеры
    ret, frame = cap.read()
    # приведение кадра к оттенкам серого
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # уменьшение шума при помощи медианного фильтра
    gray = cv2.medianBlur(gray, 3)
    # распознавание текста
    text = pytesseract.image_to_string(gray, lang=lang_model)
    # отображение распознанного текста на экране
    cv2.imshow('text', gray)

    # запись распознанного текста в файл
    with open('recognized_text.txt', 'w') as f:
        f.write(text)
        print(text)

    # прерывание цикла при нажатии клавиши 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()