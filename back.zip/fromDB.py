# получить из базы данных содержания файлов - протоколов документооборота
import sqlite3
from PyPDF2 import PdfReader


conn = sqlite3.connect('C:\db\database.db')

cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS documents 
                  (id INTEGER PRIMARY KEY, 
                   name TEXT NOT NULL, 
                   content TEXT NOT NULL,
                   date_added TEXT NOT NULL)''')


def upload_document(name, content):
    cursor.execute('''INSERT INTO documents 
                      (name, content, date_added) 
                      VALUES (?, ?, CURRENT_TIMESTAMP)''', (name, content))
    conn.commit()


def get_all_documents():
    cursor.execute('''SELECT * FROM documents''')
    rows = cursor.fetchall()
    return rows


def get_document_by_id(id):
    cursor.execute('''SELECT * FROM documents WHERE id=?''', (id,))
    row = cursor.fetchone()
    return row


with open('example.pdf', 'rb') as f:
    pdf = PdfReader(f)
    text = ""
    for page in pdf.pages:
        text += page.extract_text()

upload_document('example.pdf', text)

documents = get_all_documents()
for document in documents:
    print("ID: ", document[0])
    print("Name: ", document[1])
    print("Content: ", document[2][:50], "...")  # выводим только первые 50 символов контента
    print("Date Added: ", document[3])

document_id = 1
document = get_document_by_id(document_id)
print("ID: ", document[0])
print("Name: ", document[1])
print("Content: ", document[2])
print("Date Added: ", document[3])

conn.close()
