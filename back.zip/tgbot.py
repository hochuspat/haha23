# для телеграм бота с доступом к запросам всем участникам
TOKEN = '6117461732:AAHCmc0_z6LXMFu2QA9ov-7-KtoRSQIFIAw'
import logging
import asyncio
import signal
import sqlite3
from pprint import pprint

from aiogram import Bot, Dispatcher, types
from aiogram.types import ParseMode
from aiogram.utils import executor

# Инициализируем логгер и задаем уровень логирования
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

conn = sqlite3.connect('requests.db')
cursor = conn.cursor()

#  таблица
cursor.execute('''CREATE TABLE IF NOT EXISTS requests
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                text TEXT,
                photo_url TEXT,
                timestamp INTEGER)''')

conn.commit()

# Если столбец "photo_url" еще не существует, добавляем его в таблицу "requests"
cursor.execute("PRAGMA table_info(requests)")
columns = cursor.fetchall()
column_names = [column[1] for column in columns]
if "photo_url" not in column_names:
    cursor.execute("ALTER TABLE requests ADD COLUMN photo_url TEXT")
    conn.commit()



@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await message.reply("Привет! Я бот для обработки запросов на покупку продукции.", parse_mode=ParseMode.HTML)


@dp.message_handler(content_types=['text', 'photo'])
async def handle_message(message: types.Message):
    if message.content_type == 'text':
        text = message.text.lower()
        user_id = message.from_user.id
        timestamp = message.date
        try:

            cursor.execute("INSERT INTO requests (user_id, text, timestamp) VALUES (?, ?, ?)",
                           (user_id, text, timestamp))
            conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Failed to insert request into the database: {e}")
            await message.reply("Произошла ошибка при сохранении вашего запроса. Попробуйте позже.",
                                parse_mode=ParseMode.HTML)
        else:

            if text in ["привет", "здравствуйте", "добрый день"]:
                await message.reply("Привет!", parse_mode=ParseMode.HTML)

            elif "купить" in text or "заказать" in text:
                await message.reply("Спасибо за ваш запрос! Мы обработаем его в ближайшее время.",
                                    parse_mode=ParseMode.HTML)
            elif "связь с разработчиком" in text:
                owner_link = "https://t.me/iliaappolonov"
                await message.reply(f"Ссылка на автора канала: {owner_link}", parse_mode=ParseMode.HTML)

            else:
                await message.reply("Извините, я не совсем понимаю. Можете уточнить свой запрос?",
                                    parse_mode=ParseMode.HTML)


cursor.execute("SELECT * FROM requests")
result = cursor.fetchall()
pprint(result[:10])

# Выбираем все строки таблицы "requests"
cursor.execute("SELECT photo_url FROM requests")
result = cursor.fetchall()

for row in result:
    photo_data = row[0]
    if photo_data:
        with open("image.jpg", "wb") as f:
            f.write(photo_data)
        from PIL import Image
        im = Image.open("image.jpg")
        im.show()
    else:
        print("Фотография не найдена.")




async def main():
    await dp.start_polling()


# корректное завершение
async def shutdown(dp):
    logging.warning('Shutting down..')
    await dp.storage.close()

async def main():
    await dp.start_polling()

if __name__ == '__main__':
    asyncio.run(main())
