from flask import Flask, request, render_template, url_for, redirect

app = Flask(__name__)

# создаем список пользователей
users = {"user1": "password1", "user2": "password2", "user3": "password3"}


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username in users and users[username] == password:
            return redirect(url_for("main"))
        else:
            error_message = "Неправильный логин или пароль"
            return render_template("login.html", error_message=error_message)
    else:
        return render_template("login.html")


@app.route("/main")
def main():
    return render_template("main.html")


if __name__ == "__main__":
    app.run(debug=True)
